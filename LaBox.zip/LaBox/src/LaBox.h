/*
 * La Box Project
 * Starting include file for LaBox project
 *
 * @Author : Thierry Paris
 * @Organization : Locoduino.org
 */

#include "DCCpp.h"

#define LABOX_LIBRARY_VERSION		"0.9.1"
