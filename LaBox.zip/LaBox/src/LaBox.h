/**********************************************************************

COPYRIGHT (c) 2020 Thierry Paris

Start include file for LaBox project.

**********************************************************************/

#include "DCCpp.h"

#define LABOX_LIBRARY_VERSION		"0.7.10"
