/*************************************************************
project: <DCCpp library>
author: <Thierry PARIS>
description: <Message converter base class>
*************************************************************/

#include "Arduino.h"
#include "DCCpp.h"

#if defined(USE_THROTTLES)
MessageConverter::MessageConverter()
{
}

#endif