var searchData=
[
  ['current',['current',['../structCurrentMonitor.html#a5d7913a8c985e532b36962d2088cb676',1,'CurrentMonitor']]],
  ['currentsamplemax',['currentSampleMax',['../structCurrentMonitor.html#a12b999d776526131f8d008d3396589ff',1,'CurrentMonitor']]]
];
