var searchData=
[
  ['messagesstack',['MessagesStack',['../classMessageStack.html#a68ea39855bb6f60a331883af61fbfd79',1,'MessageStack']]],
  ['msg',['msg',['../structCurrentMonitor.html#a0d39b1f9324033a87094feebd2b1b501',1,'CurrentMonitor']]]
];
