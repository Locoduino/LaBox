var searchData=
[
  ['directionmotora',['DirectionMotorA',['../structDCCppConfig.html#a829009e0d1a84b87bcec3a125bc757cf',1,'DCCppConfig']]],
  ['directionmotorb',['DirectionMotorB',['../structDCCppConfig.html#a46b237303713bca7c18a1d2ace3d4c4c',1,'DCCppConfig']]]
];
