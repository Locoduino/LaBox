var searchData=
[
  ['ispoweronmain',['IsPowerOnMain',['../classDCCpp.html#a6a3dea562783574532fcb503694efadb',1,'DCCpp']]],
  ['ispoweronprog',['IsPowerOnProg',['../classDCCpp.html#ac669b77763326ce8cc0006c856910033',1,'DCCpp']]]
];
