var searchData=
[
  ['pin',['pin',['../structCurrentMonitor.html#a75c7b76d3cbc8207f6f77ef2b6e35301',1,'CurrentMonitor']]],
  ['poweronatfirstclient',['powerOnAtFirstClient',['../classDCCpp.html#af7aa462c3363f2ce46b62cbe38cd8fed',1,'DCCpp']]],
  ['progmonitor',['progMonitor',['../classDCCpp.html#a4b7a21c602fec12a2bd242da20ab423c',1,'DCCpp']]],
  ['progregs',['progRegs',['../classDCCpp.html#a62e7ee97cdca4a89b5130b5f7fe4f0b2',1,'DCCpp']]]
];
