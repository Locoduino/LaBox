var searchData=
[
  ['nmraname',['NMRAName',['../structDecoderManufacturer.html#ad54e012531e90fc8e83466f7f1577275',1,'DecoderManufacturer']]]
];
