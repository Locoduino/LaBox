var searchData=
[
  ['dccpp_5fdebug_5fmode',['DCCPP_DEBUG_MODE',['../DCCpp_8h.html#a51f0718b05d5d1f9e04917713f4c6ff0',1,'DCCPP_DEBUG_MODE():&#160;DCCpp.h'],['../DCCpp_8h.html#a51f0718b05d5d1f9e04917713f4c6ff0',1,'DCCPP_DEBUG_MODE():&#160;DCCpp.h']]],
  ['dccpp_5fdebug_5fverbose_5fmode',['DCCPP_DEBUG_VERBOSE_MODE',['../DCCpp_8h.html#a637cd44f2cad21dfdafa3704b73cd74f',1,'DCCpp.h']]],
  ['dccpp_5flibrary_5fversion',['DCCPP_LIBRARY_VERSION',['../DCCpp_8h.html#a8d9814dec9adda6df580a7f8fbebfa01',1,'DCCPP_LIBRARY_VERSION():&#160;DCCpp.h'],['../DCCpp_8h.html#a8d9814dec9adda6df580a7f8fbebfa01',1,'DCCPP_LIBRARY_VERSION():&#160;DCCpp.h']]],
  ['dccpp_5fprint_5fdccpp',['DCCPP_PRINT_DCCPP',['../DCCpp_8h.html#a974da9ef1ab28fef455505016a3caa57',1,'DCCPP_PRINT_DCCPP():&#160;DCCpp.h'],['../DCCpp_8h.html#a974da9ef1ab28fef455505016a3caa57',1,'DCCPP_PRINT_DCCPP():&#160;DCCpp.h']]]
];
