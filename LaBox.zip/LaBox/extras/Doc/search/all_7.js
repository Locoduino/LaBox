var searchData=
[
  ['jmriname',['JMRIName',['../structDecoderManufacturer.html#a9e0d5f5c706fdf51ecd7fef086df495c',1,'DecoderManufacturer']]]
];
